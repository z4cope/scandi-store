export const ADD_TO_CART = "ADD-TO-CART";
